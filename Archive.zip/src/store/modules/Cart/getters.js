export default {
	quantity: state => state.quantity
}
