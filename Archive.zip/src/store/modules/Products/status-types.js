export const REQUESTING = 'REQUESTING'
export const ERROR = 'ERROR'
export const DONE = 'DONE'
