import axios from 'axios'

export default axios.create({
	baseURL: 'https://boiling-reaches-93648.herokuapp.com/food-shop'
})
