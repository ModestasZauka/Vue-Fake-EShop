const Cart = () => import('@/views/Cart')

export default [
	{
		path: '/cart',
		name: 'Cart',
		component: Cart
	}
]
