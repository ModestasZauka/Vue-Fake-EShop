import Products from './Products'
import Cart from './Cart'

export default [...Products, ...Cart]
