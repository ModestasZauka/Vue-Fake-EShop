const Products = () => import('@/views/Products')

export default [
	{
		path: '/',
		name: 'Products',
		component: Products
	}
]
