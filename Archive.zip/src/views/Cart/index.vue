<template>
  <h1> Cart </h1>
</template>

<script>
export default {
	name: 'CartView'
}
</script>

<style>
</style>
